from django.apps import AppConfig


class BookdbConfig(AppConfig):
    name = 'bookdb'
